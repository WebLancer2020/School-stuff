-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2019 at 09:49 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Surname` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Username`, `Password`, `Name`, `Surname`, `Email`) VALUES
('Just ', 'Ferarri17891', 'justin', 'van', 's.d@az.co'),
('Justin12345', '12345', 'justin', 'van', 's.d@az.co'),
('Justin1789', 'Ferarri17891', 'Ingrid', 'van', 'sd@az.com'),
('Ntndo1234', '1234', 'justin', 'Mashaba', 'sd@az.com');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `Name` varchar(255) NOT NULL,
  `Surname` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Name`, `Surname`, `Email`, `Username`, `Password`) VALUES
('', '', '', 'Justin123', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_apparels`
--

CREATE TABLE `tbl_apparels` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_apparels`
--

INSERT INTO `tbl_apparels` (`ID`, `Name`, `Image`, `price`) VALUES
(1, 'blue T shirt', 'small10.jpg', 399.00),
(2, 'organe T shirt', 'small11.jpg', 399.00),
(3, 'black T shirt', 'small12.jpg', 399.00),
(4, 'Grey shorts', 'small13.jpg', 299.00),
(5, 'floral shorts', 'small14.jpg', 299.00),
(6, 'white shorts', 'small15.jpg', 299.00),
(7, 'Blue denim jacket', 'small16.jpg', 899.00),
(8, 'grey denim jacket', 'small17.jpg', 899.00),
(9, 'black denim jacket', 'small18.jpg', 899.00);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bath`
--

CREATE TABLE `tbl_bath` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Image` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_bath`
--

INSERT INTO `tbl_bath` (`ID`, `Name`, `Image`, `price`) VALUES
(1, 'cream towel', 'small19.jpg', 399.00),
(2, 'black towel', 'small20.jpg', 399.00),
(3, 'salmon pink towel', 'small21.jpg', 399.00),
(4, 'salmon pink face cloth', 'small22.jpg', 299.00),
(5, 'face cloth', 'small23.jpg', 299.00),
(6, 'cream face cloth', 'small24.jpg', 299.00),
(7, 'Moroccan bath mat ', 'small25.jpg', 599.00),
(8, 'bath mat ', 'small26.jpg', 599.00),
(9, 'bath mat ', 'small27.jpg', 599.00),
(10, 'towel', 'small19.jpg', 599.00);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`id`, `name`, `image`, `price`) VALUES
(8, 'Clock', 'small8.jpg', 300.00),
(2, 'chopping block', 'small2.jpg', 459.00),
(1, 'Grey bin', 'small1.jpg', 459.00),
(3, 'Knife set', 'small3.jpg', 599.00),
(4, 'Coffee tin', 'small4.jpg', 99.00),
(5, 'Sugar tin\r\n', 'small5.jpg', 99.00),
(6, 'Tea tin', 'small6.jpg', 99.00),
(7, 'Bread bin', 'small7.jpg', 399.00),
(9, 'shelf', 'small9.jpg', 1000.00);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_t`
--

CREATE TABLE `tbl_t` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_t`
--

INSERT INTO `tbl_t` (`id`, `name`, `image`, `price`) VALUES
(1, 'Blue shirt', 'small10.jpg', 399.00),
(2, 'orange shirt', 'small11.jpg', 399.00),
(3, 'Black shirt', 'small12.jpg', 399.00),
(4, 'Grey short', 'small13.jpg', 599.00),
(5, 'Floral short', 'small14.jpg', 599.00),
(6, 'White short', 'small15.jpg', 599.00),
(7, 'Blue denim', 'small16.jpg', 799.00),
(8, 'grey denim', 'small17.jpg', 799.00),
(9, 'Black denim', 'small18.jpg', 799.00);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tents`
--

CREATE TABLE `tbl_tents` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` double(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_tents`
--

INSERT INTO `tbl_tents` (`id`, `name`, `image`, `price`) VALUES
(1, 'tent 1', 'small19.jpg', 200.00),
(2, 'towel', 'small20.jpg', 200.00),
(3, 'Towel 3', 'small21.jpg', 200.00),
(4, 'face towel', 'small22.jpg', 99.00),
(5, 'face towel ', 'small23.jpg', 99.00),
(6, 'face towel', 'small24.jpg', 99.00),
(7, 'bathroom mat', 'small25.jpg', 399.00),
(9, 'Bathroom mat', 'small27.jpg', 399.00),
(8, 'Bathroom mat', 'small26.jpg', 399.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `tbl_apparels`
--
ALTER TABLE `tbl_apparels`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_bath`
--
ALTER TABLE `tbl_bath`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbl_product`
--
ALTER TABLE `tbl_product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_t`
--
ALTER TABLE `tbl_t`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_tents`
--
ALTER TABLE `tbl_tents`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_product`
--
ALTER TABLE `tbl_product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_tents`
--
ALTER TABLE `tbl_tents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
