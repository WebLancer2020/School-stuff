<?php

session_start();
if(!isset($_SESSION['Username'])){
	header('location:Userregistration.php');
}
$connect = mysqli_connect("localhost", "root", "", "student");


if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$count = count($_SESSION["shopping_cart"]);
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["hidden_name"],
				'item_price'		=>	$_POST["hidden_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			$_SESSION["shopping_cart"][$count] = $item_array;
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_name'			=>	$_POST["hidden_name"],
			'item_price'		=>	$_POST["hidden_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Item Removed")</script>';
				echo '<script>window.location="Members.php"</script>';
			}
		}
	}
}
?>


<!DOCTYPE html>
<html>

	<head>
		<title>Shopping cart</title>
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="Style.css">
		
	</head>
	
	<body >
		
		<div class="container">
			
		<div class="topnav">
		<a href="logout.php" text="logout" style="float: right"> <?php echo $_SESSION['Username']; ?></a>
		
		</div>
		<br>
			
		<div class="box">
			<div class="btn">
			<a href="index.php" style="text-decoration: none;">back</a>
			</div>	
				<div class="container">
                 <h2>Currency Calculator</h2>
                 <p class="lead">Convert the currency</p>
                 <form class="form-inline">
                   <div class="form-group mb-2">
                      <input type="number" class="form-control" id="amount"/>
                   </div>
                   <div class="form-group mx-sm-3 mb-2">
                      <select class="form-control" id="currency-1" required>
                        <option>ZAR</option>
                        <option>USD</option>
                      </select>
                    </div>
                    <div class="form-group mx-sm-3 mb-2">
                      <label>convert to</label>
                      <select class="form-control" id="currency-2" required>
                        <option>USD</option>
                        <option>ZAR</option>
                      </select>
                    </div>  
                    <button class="btn calculate-btn btn-primary mb-2">Convert</button>
                  </form>
                  <div class="result" >
                    <p>
                      <span class="given-amount"></span> 
                      <span class="base-currency"></span>
                      <span class="final-result"></span> 
                      <span class="second-currency"></span>
                    </p>
                  </div>
                </div> 
			<?php
				$query = "SELECT * FROM tbl_tents ORDER BY id ASC";
				$result = mysqli_query($connect, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
				?>
			<div>
			
			<?php
					}
				}
			?>
			<div style="clear:both"></div>
			<br />
			<h3 style="color: white">Order Details</h3>
			<div class="table-responsive">
				<table class="table table-bordered" width="100%">
					<tr>
						<th width="40%">Item Name</th>
						<th width="10%">Quantity</th>
						<th width="20%">Price</th>
						<th width="15%">Total</th>
						<th width="5%">Action</th>
					</tr>
					<?php
					if(!empty($_SESSION["shopping_cart"]))
					{
						$total = 0;
						foreach($_SESSION["shopping_cart"] as $keys => $values)
						{
					?>

					<tr>
						<td><?php echo $values["item_name"]; ?></td>
						<td><?php echo $values["item_quantity"]; ?></td>
						<td>R <?php echo $values["item_price"]; ?></td>
						<td>R <?php echo number_format($values["item_quantity"] * $values["item_price"], 2);?></td>
						<td><a href="index.php?action=delete&id=<?php echo $values["item_id"]; ?>" class="btn"><span class="text-danger">Remove</span></a></td>
						
					</tr>
					<?php
							$total = $total + ($values["item_quantity"] * $values["item_price"]);
						}
					?>
					<tr>
						<td colspan="3" align="right">Total</td>
						<td align="right">R <?php echo number_format($total, 2); ?></td>
						
					</tr>
					<?php
					}
					?>
						
				</table>
				
			</div>
		</div>
	</div>
	<br />
			</div>
	</body>
	<script>
    var crrncy = {'ZAR': { 'USD': 0.067}, 'USD': { 'ZAR': 14.89}}
var btn = document.querySelector('.calculate-btn');
var baseCurrencyInput = document.getElementById('currency-1');
var secondCurrencyInput = document.getElementById('currency-2');
var amountInput = document.getElementById('amount');
var toShowAmount = document.querySelector('.given-amount');
var toShowBase = document.querySelector('.base-currency');
var toShowSecond = document.querySelector('.second-currency');
var toShowResult = document.querySelector('.final-result');

function convertCurrency(event) {
  event.preventDefault();
  var amount = amountInput.value;
  var from = baseCurrencyInput.value;
  var to = secondCurrencyInput.value;
  var result = 0;
  
  try{
    if (from == to){
      result = amount;
    } else {
     result = amount * crrncy[from][to];
  }
  }
  catch(err) {
    result = amount * (1 / crrncy[to][from]);
  }
  
  toShowAmount.innerHTML = amount;
  toShowBase.textContent = from + ' = ';
  toShowSecond.textContent = to;
  toShowResult.textContent = result; 
}

btn.addEventListener('click', convertCurrency);


</script>
</html>