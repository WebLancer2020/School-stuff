<html>
<head>
	<title>User login and registration</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="styler.css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	
	<style>
		input[type="text"]::placeholder { /* Firefox, Chrome, Opera */ 
			color: #0067ab; 
		}
				input[type="password"]::placeholder { /* Firefox, Chrome, Opera */ 
			color: #0067ab;
		}
				input[type="email"]::placeholder { /* Firefox, Chrome, Opera */ 
			color: #0067ab;
		}
		
	</style>
	
	</head>
	
	<?php

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Register</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>

<div class="form">
<h1>Register</h1>
<form action="Registration.php" method="post">
<div class="form-group">
	
<input type="text" id="Uname" name="Username" class="form-control" placeholder="Username" style="border-color: #ffffff; color: #0067ab; " required>
	<br>
	<input type="password" id="Pass" name="Password" class="form-control" placeholder="Password" style="border-color: #ffffff; color: #0067ab; " required>
	<br>
	<input type="text" id="Name" name="Name" class="form-control" placeholder="Name" style="border-color: #ffffff; color: #0067ab; " required>
	<br>
	<input type="text" id="Surname" name="Surname" class="form-control" placeholder="Surname" style="border-color: #ffffff; color: #0067ab; " required>
	<br>
	<input type="email" id="Email" name="Email" class="form-control" placeholder="Email" style="border-color: #ffffff; color: #0067ab; " required>
</div>
	<button class="btn" type="submit" name="Submit" id="Submit" style="color: #ffffff; border-color: #ffffff; "> register </button>
					</form>

<br /><br />
</div>



</body>
</html>

</html>