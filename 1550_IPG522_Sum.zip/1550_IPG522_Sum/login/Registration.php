<?php

session_start();
header('location:Userregistration.php');
$con = mysqli_connect('localhost', 'root', '');

mysqli_select_db($con, 'student');


$Username = $_POST['Username'];
$Password = $_POST['Password'];
$Name = $_POST['Name'];
$Surname = $_POST['Surname'];
$Email = $_POST['Email'];


$s = "select * from login where Username = '$Username' and Password = '$Password'";

$result = mysqli_query($con, $s);

$num = mysqli_num_rows($result);

if($num == 1){
	echo" Username is already taken";
}else {
	$reg = "insert into login (Username, Password, Name, Surname, Email) values('$Username' , '$Password', '$Name', '$Surname', '$Email')";
	mysqli_query($con, $reg);
	echo("registraion successful");
}
?>