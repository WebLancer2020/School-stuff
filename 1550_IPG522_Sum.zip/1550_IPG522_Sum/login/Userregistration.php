<html>
<head>
	<title>User login and registration</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="styler.css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	
	<style>
		input[type="text"]::placeholder { /* Firefox, Chrome, Opera */ 
			color: black; 
		}
				input[type="password"]::placeholder { /* Firefox, Chrome, Opera */ 
			color: black;
		}
				input[type="email"]::placeholder { /* Firefox, Chrome, Opera */ 
			color: black;
		}
		.box{
				margin-left: 365px;
				margin-right: 365px;
			}
			.container{
				
			background-color: #8B0000;
			border: solid #000000 2px;
				border-radius: 5px;
			}
	</style>
	
	</head>
	
	<?php

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>

<div class="form">
<h1>Log In</h1>
<form action="Validation.php" method="post">
							<div class="form-group">
							<input type="text" id="Uname" name="Username" class="form-control" placeholder="Username" style="border-color: #ffffff; color: #0067ab; " required>
							<br>
							<input type="password" id="Pass" name="Password" class="form-control" placeholder="Password" style="border-color: #ffffff; color: #0067ab; " required>

						</div>
						<button class="btn" type="submit" name="Submit" id="Submit" style="color: #ffffff; border-color: #ffffff; "> Login </button>
					</form>
<p>Not registered yet? <a href="Register.php">Register Here</a></p>

<br /><br />
</div>



</body>
</html>

</html>