<?php

session_start();

$con = mysqli_connect('localhost', 'root', '');

mysqli_select_db($con, 'student');


$Username = $_POST['Username'];
$Password = $_POST['Password'];


$s = "select * from login where Username = '$Username' && Password = '$Password'";

$result = mysqli_query($con, $s);

$num = mysqli_num_rows($result);

if($num == 1){
	$_SESSION['Username'] = $Username;
	header('location:index.php');
}else {
	header('location:Userregistration.php'); 
}
?>