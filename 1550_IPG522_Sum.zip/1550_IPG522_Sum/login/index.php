<?php 
session_start();
$connect = mysqli_connect("localhost", "root", "", "student");

if(isset($_POST["add_to_cart"]))
{
	if(isset($_SESSION["shopping_cart"]))
	{
		$item_array_id = array_column($_SESSION["shopping_cart"], "item_id");
		if(!in_array($_GET["id"], $item_array_id))
		{
			$count = count($_SESSION["shopping_cart"]);
			$item_array = array(
				'item_id'			=>	$_GET["id"],
				'item_name'			=>	$_POST["hidden_name"],
				'item_price'		=>	$_POST["hidden_price"],
				'item_quantity'		=>	$_POST["quantity"]
			);
			$_SESSION["shopping_cart"][$count] = $item_array;
		}
		else
		{
			echo '<script>alert("Item Already Added")</script>';
		}
	}
	else
	{
		$item_array = array(
			'item_id'			=>	$_GET["id"],
			'item_name'			=>	$_POST["hidden_name"],
			'item_price'		=>	$_POST["hidden_price"],
			'item_quantity'		=>	$_POST["quantity"]
		);
		$_SESSION["shopping_cart"][0] = $item_array;
	}
}

if(isset($_GET["action"]))
{
	if($_GET["action"] == "delete")
	{
		foreach($_SESSION["shopping_cart"] as $keys => $values)
		{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["shopping_cart"][$keys]);
				echo '<script>alert("Item Removed")</script>';
				echo '<script>window.location="index.php"</script>';
			}
		}
	}
}

?>
<!DOCTYPE html>
<html>
	<head>
		<title>Home page</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="Style.css">
		<link rel="stylesheet" type="text/css" href="styler.css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<script>
			filterSelection("all")
			function filterSelection(c) {
				var x, i;
				x = document.getElementsByClassName("filterDiv");
				if (c == "all") c = "";
				for (i = 0; i < x.length; i++) {
				w3RemoveClass(x[i], "show");
				if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
				}
			}

			function w3AddClass(element, name) {
				var i, arr1, arr2;
				arr1 = element.className.split(" ");
				arr2 = name.split(" ");
				for (i = 0; i < arr2.length; i++) {
				if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
			  	}
			}

			function w3RemoveClass(element, name) {
				var i, arr1, arr2;
				arr1 = element.className.split(" ");
				arr2 = name.split(" ");
				for (i = 0; i < arr2.length; i++) {
					while (arr1.indexOf(arr2[i]) > -1) {
					arr1.splice(arr1.indexOf(arr2[i]), 1);
					}
			  	}
			  element.className = arr1.join(" ");
			}

// Add active class to the current button (highlight it)
			var btnContainer = document.getElementById("myBtnContainer");
			var btns = btnContainer.getElementsByClassName("btn");
			for (var i = 0; i < btns.length; i++) {
			  	btns[i].addEventListener("click", function(){
					var current = document.getElementsByClassName("active");
					current[0].className = current[0].className.replace(" active", "");
					this.className += " active";
			  });
			}
</script>
		<style>
			body{
				margin-top: -20px;
			}
			.box{
				margin-left: 365px;
				margin-right: 365px;
			}
			.filterDiv {
				float: left;
				color: #ffffff;
				width: 100%;
				line-height: 100px;
				text-align: center;
				margin: 2px;
				display: none;
			}

			.show {
			  display: block;
			}

			.container {
			  margin-top: 20px;
			  overflow: hidden;
			}

			/* Style the buttons */
			.btn {
			  border: none;
			  outline: none;
			  padding: 12px 16px;
				
			  background-color: #f1f1f1;
			  cursor: pointer;
			}
			#myBtnContainer{
				right: 300px;
			}
			.btn:hover {
			  background-color: #ddd;
			}

			.btn.active {
			  background-color: #666;
			  color: white;
			}
			
		</style>
	</head>
	<body >
		<div class="container">
			<div class="topnav">
		<a href="index.php" text="logout">Shop</a>
		<a href="Mailing.php" text="logout">Mailing list</a>
		<a href="logout.php" text="logout" style="float: right"> <?php echo $_SESSION['Username']; ?></a>
		
		</div>
		
			<div style="clear:both"></div>
			<br />
			<h3 style="color: white">Order Details</h3>
			
			
			<div id="myBtnContainer">
			<button class="btn active" onclick="filterSelection('all')"> Show all</button>
  			<button class="btn" onclick="filterSelection('Kitchen')"> Kitchen accessories</button>
  			<button class="btn" onclick="filterSelection('Bathroom')"> Bathroom accessories</button>
  			<button class="btn" onclick="filterSelection('Apparel')"> Apparel</button>
			</div>
			<div class="container">
				<div class="filterDiv Kitchen">	
				<?php
					$query = "SELECT * FROM tbl_product ORDER BY id ASC";
					$result = mysqli_query($connect, $query);
					if(mysqli_num_rows($result) > 0)
					{
						while($row = mysqli_fetch_array($result))
						{
					?>

				<div class="col-md-4">
					<form method="post" action="Mailing.php?action=add&id=<?php echo $row["id"]; ?>">
						<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
							<img src="images/<?php echo $row["image"]; ?>" class="img-responsive" /><br />

							<h4 class="text-info"><?php echo $row["name"]; ?></h4>

							<h4 class="text-danger">R <?php echo $row["price"]; ?></h4>

							<input type="text" name="quantity" value="1" class="form-control" />

							<input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

							<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />

							<input type="submit" name="add_to_cart" style="margin-top:5px; background-color: #0067ab" class="btn btn-success" value="Add to Cart" />

						</div>
					</form>
				</div>
				<?php
						}
					}
				?>


				</div>
				<div class="filterDiv Bathroom">
				<?php
					$query = "SELECT * FROM tbl_tents ORDER BY id ASC";
					$result = mysqli_query($connect, $query);
					if(mysqli_num_rows($result) > 0)
					{
						while($row = mysqli_fetch_array($result))
						{
					?>
				<div class="col-md-4">
					<form method="post" action="Mailing.php?action=add&id=<?php echo $row["id"]; ?>">
						<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
							<img src="images/<?php echo $row["image"]; ?>" class="img-responsive" /><br />

							<h4 class="text-info"><?php echo $row["name"]; ?></h4>

							<h4 class="text-danger">R <?php echo $row["price"]; ?></h4>

							<input type="text" name="quantity" value="1" class="form-control" />

							<input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

							<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />

							<input type="submit" name="add_to_cart" style="margin-top:5px; background-color: #0067ab" class="btn btn-success" value="Add to Cart" />

						</div>
					</form>
				</div>
				<?php
						}
					}
				?>


					
					</div>
				<div class="filterDiv Apparel">
				<?php
					$query = "SELECT * FROM tbl_t ORDER BY id ASC";
					$result = mysqli_query($connect, $query);
					if(mysqli_num_rows($result) > 0)
					{
						while($row = mysqli_fetch_array($result))
						{
					?>
				<div>
				<div class="col-md-4">
					<form method="post" action="Mailing.php?action=add&id=<?php echo $row["id"]; ?>">
						<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
							<img src="images/<?php echo $row["image"]; ?>" class="img-responsive" /><br />

							<h4 class="text-info"><?php echo $row["name"]; ?></h4>

							<h4 class="text-danger">R <?php echo $row["price"]; ?></h4>

							<input type="text" name="quantity" value="1" class="form-control" />

							<input type="hidden" name="hidden_name" value="<?php echo $row["name"]; ?>" />

							<input type="hidden" name="hidden_price" value="<?php echo $row["price"]; ?>" />

							<input type="submit" name="add_to_cart" style="margin-top:5px; background-color: #0067ab" class="btn btn-success" value="Add to Cart" />

						</div>
					</form>
				</div>
				<?php
						}
					}
				?>


					</div>
		</div>
				
			
		
		</div>
		</div>
		
		
	</body>
</html>